package com.emmanuelhmar.booklistingapp;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class BookAdapter extends ArrayAdapter<Book> {
    public BookAdapter(@NonNull Context context, @NonNull ArrayList<Book> books) {
        super(context, 0, books);
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        View listItemView = convertView;

        if (listItemView == null) {
            listItemView = LayoutInflater.from(getContext()).inflate(R.layout.book_list_item, parent, false);
        }

        Book book = getItem(position);



        return super.getView(position, convertView, parent);
    }

    private void setupBookView(View view, Book book) {

        String title = book.getTitle();
        List<String> authors = book.getAuthors();
        int publishedDate = book.getPublishedDate();
        double listedPrice = book.getListedPrice();

        TextView titleView = view.findViewById(R.id.title);
        titleView.setText(title);


    }
}
